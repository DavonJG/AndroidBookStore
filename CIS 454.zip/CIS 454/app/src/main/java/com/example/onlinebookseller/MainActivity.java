package com.example.onlinebookseller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;


import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<Book> lstBook;
    static List<Book> cart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cart = new ArrayList<Book>();
        lstBook = new ArrayList<Book>();
        lstBook.add(new Book("The Vegitarian","Categorie Book","Description book",R.drawable.thevigitarian,"15.99"));
        lstBook.add(new Book("The Wild Robot","Categorie Book","Description book",R.drawable.thewildrobot,"15.99"));
        lstBook.add(new Book("Maria Semples","Categorie Book","Description book",R.drawable.mariasemples,"15.99"));
        lstBook.add(new Book("The Martian","Categorie Book","Description book",R.drawable.themartian,"15.99"));
        lstBook.add(new Book("He Died with...","Categorie Book","Description book",R.drawable.hediedwith,"15.99"));
        lstBook.add(new Book("The Vegitarian","Categorie Book","Description book",R.drawable.thevigitarian,"15.99"));
        lstBook.add(new Book("The Wild Robot","Categorie Book","Description book",R.drawable.thewildrobot,"15.99"));
        lstBook.add(new Book("Maria Semples","Categorie Book","Description book",R.drawable.mariasemples,"15.99"));
        lstBook.add(new Book("The Martian","Categorie Book","Description book",R.drawable.themartian,"15.99"));
        lstBook.add(new Book("He Died with...","Categorie Book","Description book",R.drawable.hediedwith,"15.99"));
        lstBook.add(new Book("The Vegitarian","Categorie Book","Description book",R.drawable.thevigitarian,"15.99"));
        lstBook.add(new Book("The Wild Robot","Categorie Book","Description book",R.drawable.thewildrobot,"15.99"));
        lstBook.add(new Book("Maria Semples","Categorie Book","Description book",R.drawable.mariasemples,"15.99"));
        lstBook.add(new Book("The Martian","Categorie Book","Description book",R.drawable.themartian,"15.99"));
        lstBook.add(new Book("He Died with...","Categorie Book","Description book",R.drawable.hediedwith,"15.99"));

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ImageButton cart_button = findViewById(R.id.shopping_cart_button);
        cart_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,ShoppingCart.class);
                MainActivity.this.startActivity(intent);
            }
        });

        RecyclerView view = findViewById(R.id.recyclerview);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this,lstBook);
        view.setLayoutManager(new GridLayoutManager(this,3));
        view.setAdapter(adapter);


    }


}