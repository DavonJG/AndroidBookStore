package com.example.onlinebookseller;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import android.widget.Button;
import android.widget.TextView;

public class ShoppingCart extends AppCompatActivity {

    private TextView textview_toolbar_title;
    static RecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shopping_cart);

        textview_toolbar_title = findViewById(R.id.toolbar_title);
        textview_toolbar_title.setText("Shopping Cart");

        RecyclerView view = findViewById(R.id.shopping_cart_recycler);
        adapter = new RecyclerViewAdapter(this, MainActivity.cart);
        view.setLayoutManager(new LinearLayoutManager(this));
        view.setAdapter(adapter);


    }
}
