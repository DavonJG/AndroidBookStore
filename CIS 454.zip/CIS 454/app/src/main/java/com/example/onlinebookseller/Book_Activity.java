package com.example.onlinebookseller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


public class Book_Activity extends AppCompatActivity {

    private TextView textview_title,textview_description,textview_category;
    private ImageView img;
    private Button addToCartButton;
    private Book book;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);


        textview_title = findViewById(R.id.book_title);
        textview_description = findViewById(R.id.book_description);
        textview_category = findViewById(R.id.book_category);
        img = findViewById(R.id.book_thumbnail);

        // Recieve data
        book = (Book) getIntent().getSerializableExtra("Book");

        addToCartButton = findViewById(R.id.add_to_cart_button);
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.cart.add(book);

            }
        });

        ImageButton cart_button = findViewById(R.id.shopping_cart_button);
        cart_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Book_Activity.this,ShoppingCart.class);
                Book_Activity.this.startActivity(intent);
            }
        });

        textview_title.setText(book.getTitle());
        textview_description.setText(book.getDescription());
        img.setImageResource(book.getThumbnail());


    }

}
