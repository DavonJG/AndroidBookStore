package com.example.onlinebookseller;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private Context adapter_context ;
    private List<Book> book_list ;


    public RecyclerViewAdapter(Context c, List<Book> l) {
        this.adapter_context = c;
        this.book_list = l;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view ;
        LayoutInflater inflater = LayoutInflater.from(adapter_context);
        if (adapter_context.getClass().getSimpleName().compareTo("ShoppingCart") == 0){
            view = inflater.inflate(R.layout.shopping_cart_list_item,parent,false);
        }else{
            view = inflater.inflate(R.layout.book_card,parent,false);
        }

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        holder.textView_title.setText(book_list.get(position).getTitle());
        holder.textView_price.setText("$".concat(book_list.get(position).getPrice()));
        holder.book_thumbnail.setImageResource(book_list.get(position).getThumbnail());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(adapter_context,Book_Activity.class);
                intent.putExtra("Book",book_list.get(position));

                adapter_context.startActivity(intent);

            }
        });

        if (adapter_context.getClass().getSimpleName().compareTo("ShoppingCart") == 0){
            holder.view_remove_cart_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MainActivity.cart.remove(book_list.get(position));
                    ShoppingCart.adapter.notifyItemRemoved(position);
                }
            });
        }


    }

    @Override
    public int getItemCount() {
        return book_list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView textView_title;
        TextView textView_price;
        ImageView book_thumbnail;
        CardView cardView;
        Button view_remove_cart_button;

        public ViewHolder(View itemView) {
            super(itemView);

            if (adapter_context.getClass().getSimpleName().compareTo("ShoppingCart") == 0){
                textView_title = itemView.findViewById(R.id.cart_item_title);
                textView_price = itemView.findViewById(R.id.cart_item_price) ;
                book_thumbnail = itemView.findViewById(R.id.cart_img);
                cardView = itemView.findViewById(R.id.shopping_cart_item);
                view_remove_cart_button = itemView.findViewById(R.id.remove_cart_button);
            }else{
                textView_title = itemView.findViewById(R.id.book_title);
                textView_price = itemView.findViewById(R.id.book_price) ;
                book_thumbnail = itemView.findViewById(R.id.book_img);
                cardView = itemView.findViewById(R.id.cardview);
            }



        }
    }


}