package com.example.onlinebookseller;


import java.io.Serializable;

public class Book implements Serializable {

    private String Title;
    private String Category ;
    private String Description ;
    private int Thumbnail ;
    private String Price;

    public Book() {
    }

    public Book(String title, String category, String description, int thumbnail, String price) {
        Title = title;
        Category = category;
        Description = description;
        Thumbnail = thumbnail;
        Price = price;
    }


    public String getTitle() {
        return Title;
    }

    public String getCategory() {
        return Category;
    }

    public String getDescription() {
        return Description;
    }

    public int getThumbnail() {
        return Thumbnail;
    }

    public String getPrice() {
        return Price;
    }


    public void setTitle(String title) {
        Title = title;
    }

    public void setCategory(String category) {
        Category = category;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public void setThumbnail(int thumbnail) {
        Thumbnail = thumbnail;
    }

    public void setPrice(String price) {
        Price = price;
    }
}
